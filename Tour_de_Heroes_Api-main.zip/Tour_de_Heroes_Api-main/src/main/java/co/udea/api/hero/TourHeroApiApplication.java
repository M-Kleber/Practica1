package co.udea.api.hero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourHeroApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(TourHeroApiApplication.class, args);
    }

}

