package co.udea.api.hero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourHeroApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
